"""Diagnose why the FinTel dashboard sees no Gold data."""

from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
GOLD = ROOT / "data" / "gold" / "sentiment_price"
AUDIT = ROOT / "data" / "audit" / "gold_aggregation_audit.jsonl"

print("=" * 60)
print("ROOT       :", ROOT)
print("GOLD_PATH  :", GOLD)
print("Exists     :", GOLD.exists())
print("=" * 60)

if not GOLD.exists():
    print("\n[X] Folder does not exist. Searching for it...")
    for p in ROOT.rglob("sentiment_price"):
        print("   FOUND ->", p)
    for p in ROOT.rglob("_delta_log"):
        print("   DELTA TABLE ->", p.parent)
    raise SystemExit

print("\nContents:")
for item in list(GOLD.iterdir())[:15]:
    print("  ", item.name)

parquets = list(GOLD.rglob("*.parquet"))
print(f"\nParquet files: {len(parquets)}")
print("Has _delta_log:", (GOLD / "_delta_log").exists())

if not parquets:
    print("\n[X] No data files. The pipeline has not committed a batch yet.")
    raise SystemExit

# --- try Delta first ---
df = None
try:
    from deltalake import DeltaTable
    df = DeltaTable(str(GOLD)).to_pandas()
    print(f"\n[OK] Delta read: {len(df)} rows")
except Exception as e:
    print(f"\n[!] Delta read FAILED: {type(e).__name__}: {e}")
    df = pd.concat((pd.read_parquet(f) for f in parquets), ignore_index=True)
    print(f"[OK] Parquet fallback: {len(df)} rows")

print("\nColumns:", list(df.columns))

if df.empty:
    print("\n[X] Table exists but contains 0 rows.")
    raise SystemExit

df["window_end"] = pd.to_datetime(df["window_end"], errors="coerce")

print("\n--- TIME ANALYSIS (the usual culprit) ---")
print("Min window_end :", df["window_end"].min())
print("Max window_end :", df["window_end"].max())
print("tz-aware       :", df['window_end'].dt.tz is not None)
print("Local now      :", pd.Timestamp.now())
print("UTC now        :", pd.Timestamp.utcnow())

newest = df["window_end"].max()
if newest.tz is not None:
    newest = newest.tz_localize(None)

age_local = (pd.Timestamp.now() - newest).total_seconds() / 3600
age_utc = (pd.Timestamp.utcnow().tz_localize(None) - newest).total_seconds() / 3600

print(f"\nAge vs LOCAL now : {age_local:.2f} hours")
print(f"Age vs UTC now   : {age_utc:.2f} hours")

if age_utc > 6 >= age_local:
    print("\n>>> CONFIRMED: timezone mismatch. Data is recent in LOCAL time")
    print(">>> but looks 5.5h old against UTC, so the 6h filter drops it.")
elif age_local > 6:
    print("\n>>> Data is genuinely older than the 6h slider. Raise the slider.")
else:
    print("\n>>> Time looks fine. Issue is elsewhere.")

print("\nSample rows:")
print(df.sort_values("window_end").tail(3).to_string())