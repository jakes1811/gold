"""
GOLD LAYER - FinTel Phase 4  (v2)

TEMPORARY STATE: write-path restoration.
    News stream DISABLED. News columns emitted as typed nulls.
    Stream-stream join to be reinstated after writes are confirmed.

Key fix vs v1:
    app_id is run-scoped (RUN_TAG) so Delta idempotent-write
    de-duplication can never silently skip a batch.
"""

import time

from pyspark.sql import functions as F
from pyspark.sql.streaming import StreamingQueryListener

from common import audit
from common.schemas import SILVER_TICKS_DDL
from common.tables import read_stream, write_batch
from config import settings


# =========================================================
# CONSTANTS
# =========================================================

JOB = "gold_job"
QUERY_NAME = "gold-sentiment-price"

# Set True to re-enable the news stream later.
NEWS_ENABLED = False

# Unique per process start - defeats Delta txn de-duplication.
RUN_TAG = str(int(time.time()))

GOLD_COLUMNS = [
    "window_start",
    "window_end",
    "symbol",
    "article_count",
    "avg_sentiment",
    "min_sentiment",
    "latest_headline",
    "latest_sentiment_label",
    "price_first",
    "price_last",
    "price_high",
    "price_low",
    "price_change_pct",
    "price_range_pct",
    "tick_count",
    "day_change_pct",
    "alert_flag",
    "alert_reason",
    "computed_at",
]

_batch_outputs = {}


# =========================================================
# BUILD GOLD STREAM
# =========================================================

def build_gold_stream(ticks_raw, news_raw=None):
    """Price windows only. News columns are typed nulls."""

    ticks = (
        ticks_raw
        .where(F.col("current_price") > 0)
        .where(F.col("publication_timestamp").isNotNull())
        .select(
            F.col("symbol"),
            F.col("current_price").alias("price"),
            F.col("change_percent"),
            F.col("publication_timestamp").alias("tick_time"),
        )
        .withWatermark("tick_time", settings.WATERMARK)
    )

    tick_win = (
        ticks
        .groupBy(
            F.col("symbol"),
            F.window(
                "tick_time",
                settings.WINDOW_DURATION,
                settings.SLIDE_DURATION,
            ).alias("w"),
        )
        .agg(
            F.min_by("price", "tick_time").alias("price_first"),
            F.max_by("price", "tick_time").alias("price_last"),
            F.max("price").alias("price_high"),
            F.min("price").alias("price_low"),
            F.count(F.lit(1)).alias("tick_count"),
            F.max_by("change_percent", "tick_time").alias(
                "day_change_pct"
            ),
        )
    )

    # ---- NEWS DISABLED: only ONE stateful operator remains ----
    joined = (
        tick_win
        .withColumn("article_count", F.lit(0).cast("int"))
        .withColumn("avg_sentiment", F.lit(None).cast("double"))
        .withColumn("min_sentiment", F.lit(None).cast("double"))
        .withColumn("latest_headline", F.lit(None).cast("string"))
        .withColumn(
            "latest_sentiment_label", F.lit(None).cast("string")
        )
    )

    change = (
        (F.col("price_last") - F.col("price_first"))
        / F.col("price_first")
        * 100
    )

    bad_sentiment = (
        F.col("avg_sentiment")
        <= F.lit(settings.ALERT_SENTIMENT_THRESHOLD)
    )

    price_drop = change <= F.lit(settings.ALERT_PRICE_DROP_PCT)

    gold = (
        joined
        .select(
            F.col("w.start").alias("window_start"),
            F.col("w.end").alias("window_end"),
            F.col("symbol"),
            F.coalesce(
                F.col("article_count"), F.lit(0)
            ).cast("int").alias("article_count"),
            F.col("avg_sentiment"),
            F.col("min_sentiment"),
            F.col("latest_headline"),
            F.col("latest_sentiment_label"),
            F.col("price_first"),
            F.col("price_last"),
            F.col("price_high"),
            F.col("price_low"),
            change.alias("price_change_pct"),
            (
                (F.col("price_high") - F.col("price_low"))
                / F.col("price_first")
                * 100
            ).alias("price_range_pct"),
            F.col("tick_count").cast("long").alias("tick_count"),
            F.col("day_change_pct"),
        )
        .withColumn(
            "price_change_pct", F.round("price_change_pct", 4)
        )
        .withColumn(
            "price_range_pct", F.round("price_range_pct", 4)
        )
        .withColumn(
            "alert_flag", F.coalesce(bad_sentiment, F.lit(False))
        )
        .withColumn(
            "alert_reason",
            F.when(
                bad_sentiment & price_drop,
                F.concat(
                    F.lit("negative sentiment ("),
                    F.round("avg_sentiment", 2).cast("string"),
                    F.lit(") with price drop ("),
                    F.round("price_change_pct", 2).cast("string"),
                    F.lit("%)"),
                ),
            ).when(
                bad_sentiment,
                F.concat(
                    F.lit("negative sentiment ("),
                    F.round("avg_sentiment", 2).cast("string"),
                    F.lit("), price not yet reacting"),
                ),
            ),
        )
        .withColumn("computed_at", F.current_timestamp())
        .select(*GOLD_COLUMNS)
    )

    return gold


# =========================================================
# GOLD PROGRESS AUDIT
# =========================================================

class GoldProgressAudit(StreamingQueryListener):

    def __init__(self, run_id):
        super().__init__()
        self.run_id = run_id

    def onQueryStarted(self, event):
        pass

    def onQueryIdle(self, event):
        pass

    def onQueryTerminated(self, event):
        pass

    def onQueryProgress(self, event):

        p = event.progress

        if p.name != QUERY_NAME:
            return

        tick_in = 0
        for source in p.sources:
            tick_in += int(source.numInputRows or 0)

        late = sum(
            int(getattr(op, "numRowsDroppedByWatermark", 0) or 0)
            for op in p.stateOperators
        )

        rows, wmin, wmax = _batch_outputs.pop(
            p.batchId, (0, None, None)
        )

        audit.write_audit(
            "gold_aggregation_audit",
            {
                "run_id": self.run_id,
                "job_name": JOB,
                "batch_id": int(p.batchId),
                "window_start_min": wmin,
                "window_end_max": wmax,
                "input_news_count": 0,
                "input_tick_count": tick_in,
                "output_row_count": rows,
                "late_records": late,
                "duration_ms": int(
                    (p.durationMs or {}).get("triggerExecution", 0)
                ),
                "status": "OK",
            },
        )


# =========================================================
# OPTIONAL POSTGRES UPSERT
# =========================================================

def _postgres_upsert(rows):

    import psycopg2

    con = psycopg2.connect(
        host=settings.PG_HOST,
        port=settings.PG_PORT,
        dbname=settings.PG_DB,
        user=settings.PG_USER,
        password=settings.PG_PASSWORD,
        connect_timeout=5,
    )

    cols = GOLD_COLUMNS

    sets = ", ".join(
        f"{c}=EXCLUDED.{c}"
        for c in cols
        if c not in ("window_start", "symbol")
    )

    with con, con.cursor() as cur:

        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS gold_sentiment_price (
                window_start TIMESTAMPTZ NOT NULL,
                window_end TIMESTAMPTZ,
                symbol TEXT NOT NULL,
                article_count INT,
                avg_sentiment DOUBLE PRECISION,
                min_sentiment DOUBLE PRECISION,
                latest_headline TEXT,
                latest_sentiment_label TEXT,
                price_first DOUBLE PRECISION,
                price_last DOUBLE PRECISION,
                price_high DOUBLE PRECISION,
                price_low DOUBLE PRECISION,
                price_change_pct DOUBLE PRECISION,
                price_range_pct DOUBLE PRECISION,
                tick_count BIGINT,
                day_change_pct DOUBLE PRECISION,
                alert_flag BOOLEAN,
                alert_reason TEXT,
                computed_at TIMESTAMPTZ,
                PRIMARY KEY (window_start, symbol)
            )
            """
        )

        for r in rows:
            cur.execute(
                f"""
                INSERT INTO gold_sentiment_price
                ({','.join(cols)})
                VALUES ({','.join(['%s'] * len(cols))})
                ON CONFLICT (window_start, symbol)
                DO UPDATE SET {sets}
                """,
                [r[c] for c in cols],
            )

    con.close()


# =========================================================
# START GOLD STREAMING JOB
# =========================================================

def start_gold(spark, run_id):

    if not settings.SILVER_TICKS_PATH.exists():
        raise FileNotFoundError(
            f"Stock Silver path not found: "
            f"{settings.SILVER_TICKS_PATH}"
        )

    ticks_raw = read_stream(
        spark,
        settings.SILVER_TICKS_PATH,
        SILVER_TICKS_DDL,
        fmt=settings.SILVER_TICKS_FORMAT,
        options={"maxFilesPerTrigger": "50"},
    )

    print("\n[GOLD] INPUT CONFIGURATION")
    print("[GOLD] Stock Silver :", settings.SILVER_TICKS_PATH)
    print("[GOLD] Stock format :", settings.SILVER_TICKS_FORMAT)
    print("[GOLD] News enabled :", NEWS_ENABLED)
    print("[GOLD] Window       :", settings.WINDOW_DURATION)
    print("[GOLD] Slide        :", settings.SLIDE_DURATION)
    print("[GOLD] Watermark    :", settings.WATERMARK)
    print("[GOLD] Trigger      :", settings.GOLD_TRIGGER)
    print("[GOLD] Output mode  : update")
    print("[GOLD] Run tag      :", RUN_TAG)
    print("[GOLD] Gold output  :", settings.GOLD_PATH)
    print("[GOLD] Spark version:", spark.version)

    gold = build_gold_stream(ticks_raw, None)

    totals = {"rows": 0}

    def process(batch_df, batch_id):

        batch_df.persist()

        try:
            stats = batch_df.agg(
                F.count("*").alias("n"),
                F.min("window_start").alias("a"),
                F.max("window_end").alias("b"),
            ).collect()[0]

            n = int(stats["n"])
            _batch_outputs[batch_id] = (n, stats["a"], stats["b"])

            if n == 0:
                print(f"[GOLD] Batch {batch_id}: 0 rows")
                return

            print(
                f"[GOLD] Batch {batch_id}: {n} window rows "
                f"({stats['a']} .. {stats['b']})"
            )

            try:
                write_batch(
                    batch_df,
                    settings.GOLD_PATH,
                    app_id=f"gold-sentiment-price-{RUN_TAG}",
                    batch_id=batch_id,
                )
                print(
                    f"[GOLD] write_batch OK -> {settings.GOLD_PATH}"
                )

            except Exception as error:
                print(f"[GOLD] write_batch FAILED: {error}")

                fallback = (
                    settings.GOLD_PATH.parent
                    / "sentiment_price_parquet"
                )

                (
                    batch_df.write
                    .mode("append")
                    .parquet(str(fallback))
                )

                print(f"[GOLD] Parquet fallback -> {fallback}")

            totals["rows"] += n

            if settings.PG_ENABLED:
                try:
                    _postgres_upsert(
                        [r.asDict() for r in batch_df.collect()]
                    )
                except Exception as error:
                    print(f"[GOLD] Postgres skipped: {error}")

            audit.job_heartbeat(run_id, JOB, totals["rows"])

        except Exception as error:
            print(f"[GOLD] Batch {batch_id} ERROR: {error}")
            raise

        finally:
            batch_df.unpersist()

    spark.streams.addListener(GoldProgressAudit(run_id))

    query = (
        gold.writeStream
        .queryName(QUERY_NAME)
        .outputMode("update")
        .foreachBatch(process)
        .option(
            "checkpointLocation",
            str(settings.GOLD_CHECKPOINT_PATH),
        )
        .trigger(processingTime=settings.GOLD_TRIGGER)
        .start()
    )

    print("\n[GOLD] Streaming query started successfully.")
    print("[GOLD] Query ID:", query.id)

    return query