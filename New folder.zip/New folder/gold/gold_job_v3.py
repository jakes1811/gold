"""
GOLD LAYER - FinTel Phase 4  (v3)

News re-enabled via STATIC AS-OF JOIN.

Four problems solved here:

1. Density
   ~56 articles over 11 days against 1-minute tick windows
   gives a window-equality join roughly a 1-in-280 hit rate.
   Instead we attach the most recent article at or before
   window_end, carried forward up to NEWS_MAX_AGE_HOURS.

2. Nanosecond timestamps
   The news parquet files were written by pandas/pyarrow with
   TIMESTAMP(NANOS). Spark's parquet reader rejects that type
   outright (PARQUET_TYPE_ILLEGAL). So news is read through
   pandas, downcast to microseconds, and handed to Spark.

3. Multi-ticker articles
   The news Silver stores matched_tickers as a LIST per
   article - one story can mention several symbols. We explode
   to one row per (article, ticker) pair before joining.

4. Python worker spawn on Windows
   createDataFrame(pandas) needs a Python worker. Spark spawns
   it as bare "python", which hits the Microsoft Store alias
   stub. We pin the interpreter, and keep a worker-free
   fallback via temp parquet round-trip.

Result: only ONE stateful operator (the tick window), no
watermark coupling between streams.
"""


import os
import sys

os.environ["PYSPARK_PYTHON"] = sys.executable
os.environ["PYSPARK_DRIVER_PYTHON"] = sys.executable

# Force all Spark-internal networking onto loopback.
# Without this, BlockManager registration can resolve to a
# null/ambiguous host and worker connect-back times out.
os.environ["SPARK_LOCAL_IP"] = "127.0.0.1"
os.environ["SPARK_LOCAL_HOSTNAME"] = "localhost"

import time

from pyspark.sql import functions as F
from pyspark.sql.streaming import StreamingQueryListener

from common import audit
from common.schemas import SILVER_TICKS_DDL
from common.tables import read_stream, write_batch
from config import settings


# =========================================================
# CONSTANTS
# =========================================================

JOB = "gold_job"
QUERY_NAME = "gold-sentiment-price"

NEWS_ENABLED = True

# How far back an article may be carried forward.
NEWS_MAX_AGE_HOURS = 24

# Unique per process start - defeats Delta txn de-duplication.
RUN_TAG = str(int(time.time()))

# Candidate column names, tried in order.
NEWS_SYMBOL_CANDIDATES = [
    "matched_tickers",
    "matched_ticker",
    "symbol",
    "ticker",
    "stock_symbol",
]

NEWS_TIME_CANDIDATES = [
    "published_at",
    "publication_timestamp",
    "news_time",
    "published_time",
    "ingested_at",
]

NEWS_SCORE_CANDIDATES = [
    "sentiment_score",
    "score",
    "compound",
]

NEWS_LABEL_CANDIDATES = [
    "sentiment_label",
    "sentiment",
    "label",
    "sentiment_class",
]

NEWS_HEADLINE_CANDIDATES = [
    "headline",
    "title",
    "news_title",
]

GOLD_COLUMNS = [
    "window_start",
    "window_end",
    "symbol",
    "article_count",
    "avg_sentiment",
    "min_sentiment",
    "latest_headline",
    "latest_sentiment_label",
    "price_first",
    "price_last",
    "price_high",
    "price_low",
    "price_change_pct",
    "price_range_pct",
    "tick_count",
    "day_change_pct",
    "alert_flag",
    "alert_reason",
    "computed_at",
]

NEWS_SPARK_SCHEMA = (
    "news_symbol string, "
    "news_time timestamp, "
    "news_score double, "
    "news_label string, "
    "news_headline string"
)

_batch_outputs = {}
_news_cache = {"df": None, "count": 0, "loaded_at": 0.0}

NEWS_CACHE_TTL_SECONDS = 60


# =========================================================
# COLUMN RESOLUTION
# =========================================================

def _pick(available, candidates, purpose):
    """Return the first candidate present in available."""

    lowered = {c.lower(): c for c in available}

    for cand in candidates:
        if cand.lower() in lowered:
            return lowered[cand.lower()]

    raise KeyError(
        f"[GOLD] Could not resolve {purpose} column. "
        f"Tried {candidates}. Available: {sorted(available)}"
    )


def _normalise_symbol(col):
    """Strip common exchange suffixes and upper-case."""

    cleaned = F.upper(F.trim(col))
    cleaned = F.regexp_replace(cleaned, r"\.(NS|BO|NSE|BSE)$", "")

    return cleaned


# =========================================================
# PANDAS -> SPARK  (two strategies)
# =========================================================

def _pandas_to_spark(spark, out):
    """
    Hand a pandas frame to Spark.

    Primary path is createDataFrame, which needs a Python
    worker process. On Windows that spawn can fail against
    the Store alias stub, so the fallback writes a temp
    parquet (already microsecond-typed) and reads it back
    through the JVM reader - no Python worker involved.
    """

    try:
        df = spark.createDataFrame(out, schema=NEWS_SPARK_SCHEMA)
        df = df.persist()
        n = df.count()

        return df, n

    except Exception as error:
        print(f"[GOLD] createDataFrame failed: {error}")
        print("[GOLD] Falling back to temp parquet round-trip.")

    import tempfile

    tmp_dir = os.path.join(
        tempfile.gettempdir(), f"fintel_news_{RUN_TAG}"
    )

    os.makedirs(tmp_dir, exist_ok=True)

    tmp_file = os.path.join(tmp_dir, "news.parquet")

    out.to_parquet(
        tmp_file,
        index=False,
        coerce_timestamps="us",
        allow_truncated_timestamps=True,
    )

    df = spark.read.parquet(tmp_file).persist()
    n = df.count()

    print(f"[GOLD] Temp parquet fallback OK -> {tmp_file}")

    return df, n


# =========================================================
# STATIC NEWS SNAPSHOT  (pandas reader)
# =========================================================

def _load_news_snapshot(spark):
    """
    Read news Silver via pandas, not Spark.

    Spark's parquet reader has no code path for
    TIMESTAMP(NANOS) and fails with PARQUET_TYPE_ILLEGAL.
    Pandas reads it natively, so we downcast to microseconds
    and build the Spark DataFrame from there.
    """

    now = time.time()

    fresh = (
        _news_cache["df"] is not None
        and (now - _news_cache["loaded_at"]) < NEWS_CACHE_TTL_SECONDS
    )

    if fresh:
        return _news_cache["df"], _news_cache["count"]

    import glob
    import pandas as pd

    base = str(settings.SILVER_NEWS_PATH)

    files = glob.glob(base + "/**/*.parquet", recursive=True)
    files = [f for f in files if "_delta_log" not in f]

    if not files:
        raise FileNotFoundError(
            f"[GOLD] No news parquet files under {base}"
        )

    frames = []

    for f in files:
        try:
            frames.append(pd.read_parquet(f))
        except Exception as error:
            print(f"[GOLD] Skipped news file {f}: {error}")

    if not frames:
        raise ValueError("[GOLD] All news files failed to read")

    pdf = pd.concat(frames, ignore_index=True)

    cols = list(pdf.columns)

    sym_c = _pick(cols, NEWS_SYMBOL_CANDIDATES, "news symbol")
    time_c = _pick(cols, NEWS_TIME_CANDIDATES, "news timestamp")
    score_c = _pick(cols, NEWS_SCORE_CANDIDATES, "sentiment score")

    try:
        label_c = _pick(
            cols, NEWS_LABEL_CANDIDATES, "sentiment label"
        )
    except KeyError:
        label_c = None

    try:
        head_c = _pick(cols, NEWS_HEADLINE_CANDIDATES, "headline")
    except KeyError:
        head_c = None

    # matched_tickers holds a list per article - one story
    # can mention several symbols. Explode to one row per
    # (article, ticker) pair before building the join key.
    def _to_list(v):
        if v is None:
            return []
        if isinstance(v, (list, tuple, set)):
            return list(v)
        if hasattr(v, "tolist"):
            return list(v.tolist())
        if isinstance(v, str):
            s = v.strip().strip("[]")
            if not s:
                return []
            return [p.strip(" '\"") for p in s.split(",")]
        return [v]

    pdf = pdf.copy()
    pdf["_sym_list"] = pdf[sym_c].apply(_to_list)
    pdf = pdf.explode("_sym_list", ignore_index=True)

    out = pd.DataFrame(index=pdf.index)

    out["news_symbol"] = (
        pdf["_sym_list"]
        .astype("string")
        .str.strip()
        .str.upper()
        .str.replace(r"\.(NS|BO|NSE|BSE)$", "", regex=True)
    )

    # nanos -> micros, drop tz for Spark
    ts = pd.to_datetime(pdf[time_c], errors="coerce", utc=True)
    out["news_time"] = (
        ts.dt.tz_localize(None).astype("datetime64[us]")
    )

    out["news_score"] = pd.to_numeric(
        pdf[score_c], errors="coerce"
    ).astype("float64")

    out["news_label"] = (
        pdf[label_c].astype("string")
        if label_c
        else pd.Series([None] * len(pdf), dtype="string")
    )

    out["news_headline"] = (
        pdf[head_c].astype("string")
        if head_c
        else pd.Series([None] * len(pdf), dtype="string")
    )

    out = out.dropna(subset=["news_time", "news_symbol"])

    out = out[out["news_symbol"].str.len() > 0]

    out = out.astype(
        {
            "news_symbol": "object",
            "news_label": "object",
            "news_headline": "object",
        }
    )

    out = out.where(pd.notnull(out), None)

    out = out.reset_index(drop=True)

    if out.empty:
        raise ValueError("[GOLD] News frame empty after cleaning")

    news, n = _pandas_to_spark(spark, out)

    print(
        f"[GOLD] News loaded via pandas: {n} rows "
        f"from {len(files)} files "
        f"(symbol={sym_c}, time={time_c}, score={score_c})"
    )

    syms = sorted(
        r["news_symbol"]
        for r in news.select("news_symbol").distinct().collect()
    )

    print(f"[GOLD] News symbols ({len(syms)}): {syms[:20]}")

    _news_cache["df"] = news
    _news_cache["count"] = n
    _news_cache["loaded_at"] = now

    return news, n


# =========================================================
# AS-OF JOIN
# =========================================================

def _attach_news(spark, price_df):
    """Attach latest article at or before window_end."""

    news, n_news = _load_news_snapshot(spark)

    if n_news == 0:
        return price_df, 0

    max_age = F.expr(f"INTERVAL {NEWS_MAX_AGE_HOURS} HOURS")

    keys = price_df.select(
        "window_start", "window_end", "symbol"
    ).distinct()

    candidates = (
        keys.join(
            F.broadcast(news),
            keys["symbol"] == news["news_symbol"],
            "left",
        )
        .where(
            F.col("news_time").isNull()
            | (
                (F.col("news_time") <= F.col("window_end"))
                & (
                    F.col("news_time")
                    >= F.col("window_start") - max_age
                )
            )
        )
    )

    in_window = (
        (F.col("news_time") >= F.col("window_start"))
        & (F.col("news_time") < F.col("window_end"))
    )

    agg = (
        candidates
        .groupBy("window_start", "window_end", "symbol")
        .agg(
            F.sum(
                F.when(in_window, F.lit(1)).otherwise(F.lit(0))
            ).cast("int").alias("article_count"),
            F.avg("news_score").alias("avg_sentiment"),
            F.min("news_score").alias("min_sentiment"),
            F.max_by("news_headline", "news_time").alias(
                "latest_headline"
            ),
            F.max_by("news_label", "news_time").alias(
                "latest_sentiment_label"
            ),
        )
    )

    enriched = (
        price_df.drop(
            "article_count",
            "avg_sentiment",
            "min_sentiment",
            "latest_headline",
            "latest_sentiment_label",
        )
        .join(
            F.broadcast(agg),
            ["window_start", "window_end", "symbol"],
            "left",
        )
    )

    return enriched, n_news


# =========================================================
# BUILD GOLD STREAM (price side only)
# =========================================================

def build_gold_stream(ticks_raw):
    """Windowed price aggregation. News attached per batch."""

    ticks = (
        ticks_raw
        .where(F.col("current_price") > 0)
        .where(F.col("publication_timestamp").isNotNull())
        .select(
            _normalise_symbol(F.col("symbol")).alias("symbol"),
            F.col("current_price").alias("price"),
            F.col("change_percent"),
            F.col("publication_timestamp").alias("tick_time"),
        )
        .withWatermark("tick_time", settings.WATERMARK)
    )

    tick_win = (
        ticks
        .groupBy(
            F.col("symbol"),
            F.window(
                "tick_time",
                settings.WINDOW_DURATION,
                settings.SLIDE_DURATION,
            ).alias("w"),
        )
        .agg(
            F.min_by("price", "tick_time").alias("price_first"),
            F.max_by("price", "tick_time").alias("price_last"),
            F.max("price").alias("price_high"),
            F.min("price").alias("price_low"),
            F.count(F.lit(1)).alias("tick_count"),
            F.max_by("change_percent", "tick_time").alias(
                "day_change_pct"
            ),
        )
    )

    change = (
        (F.col("price_last") - F.col("price_first"))
        / F.col("price_first")
        * 100
    )

    price_df = (
        tick_win
        .select(
            F.col("w.start").alias("window_start"),
            F.col("w.end").alias("window_end"),
            F.col("symbol"),
            F.col("price_first"),
            F.col("price_last"),
            F.col("price_high"),
            F.col("price_low"),
            F.round(change, 4).alias("price_change_pct"),
            F.round(
                (F.col("price_high") - F.col("price_low"))
                / F.col("price_first")
                * 100,
                4,
            ).alias("price_range_pct"),
            F.col("tick_count").cast("long").alias("tick_count"),
            F.col("day_change_pct"),
        )
    )

    return price_df


# =========================================================
# ALERT DERIVATION (applied post-join, per batch)
# =========================================================

def _apply_alerts(df):

    bad_sentiment = (
        F.col("avg_sentiment")
        <= F.lit(settings.ALERT_SENTIMENT_THRESHOLD)
    )

    price_drop = (
        F.col("price_change_pct")
        <= F.lit(settings.ALERT_PRICE_DROP_PCT)
    )

    return (
        df
        .withColumn(
            "article_count",
            F.coalesce(F.col("article_count"), F.lit(0)).cast("int"),
        )
        .withColumn(
            "alert_flag",
            F.coalesce(bad_sentiment, F.lit(False)),
        )
        .withColumn(
            "alert_reason",
            F.when(
                bad_sentiment & price_drop,
                F.concat(
                    F.lit("negative sentiment ("),
                    F.round("avg_sentiment", 2).cast("string"),
                    F.lit(") with price drop ("),
                    F.round("price_change_pct", 2).cast("string"),
                    F.lit("%)"),
                ),
            ).when(
                bad_sentiment,
                F.concat(
                    F.lit("negative sentiment ("),
                    F.round("avg_sentiment", 2).cast("string"),
                    F.lit("), price not yet reacting"),
                ),
            ),
        )
        .withColumn("computed_at", F.current_timestamp())
        .select(*GOLD_COLUMNS)
    )


# =========================================================
# GOLD PROGRESS AUDIT
# =========================================================

class GoldProgressAudit(StreamingQueryListener):

    def __init__(self, run_id):
        super().__init__()
        self.run_id = run_id

    def onQueryStarted(self, event):
        pass

    def onQueryIdle(self, event):
        pass

    def onQueryTerminated(self, event):
        pass

    def onQueryProgress(self, event):

        p = event.progress

        if p.name != QUERY_NAME:
            return

        tick_in = 0
        for source in p.sources:
            tick_in += int(source.numInputRows or 0)

        late = sum(
            int(getattr(op, "numRowsDroppedByWatermark", 0) or 0)
            for op in p.stateOperators
        )

        rows, wmin, wmax, news_n = _batch_outputs.pop(
            p.batchId, (0, None, None, 0)
        )

        audit.write_audit(
            "gold_aggregation_audit",
            {
                "run_id": self.run_id,
                "job_name": JOB,
                "batch_id": int(p.batchId),
                "window_start_min": wmin,
                "window_end_max": wmax,
                "input_news_count": news_n,
                "input_tick_count": tick_in,
                "output_row_count": rows,
                "late_records": late,
                "duration_ms": int(
                    (p.durationMs or {}).get("triggerExecution", 0)
                ),
                "status": "OK",
            },
        )


# =========================================================
# OPTIONAL POSTGRES UPSERT
# =========================================================

def _postgres_upsert(rows):

    import psycopg2

    con = psycopg2.connect(
        host=settings.PG_HOST,
        port=settings.PG_PORT,
        dbname=settings.PG_DB,
        user=settings.PG_USER,
        password=settings.PG_PASSWORD,
        connect_timeout=5,
    )

    cols = GOLD_COLUMNS

    sets = ", ".join(
        f"{c}=EXCLUDED.{c}"
        for c in cols
        if c not in ("window_start", "symbol")
    )

    with con, con.cursor() as cur:

        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS gold_sentiment_price (
                window_start TIMESTAMPTZ NOT NULL,
                window_end TIMESTAMPTZ,
                symbol TEXT NOT NULL,
                article_count INT,
                avg_sentiment DOUBLE PRECISION,
                min_sentiment DOUBLE PRECISION,
                latest_headline TEXT,
                latest_sentiment_label TEXT,
                price_first DOUBLE PRECISION,
                price_last DOUBLE PRECISION,
                price_high DOUBLE PRECISION,
                price_low DOUBLE PRECISION,
                price_change_pct DOUBLE PRECISION,
                price_range_pct DOUBLE PRECISION,
                tick_count BIGINT,
                day_change_pct DOUBLE PRECISION,
                alert_flag BOOLEAN,
                alert_reason TEXT,
                computed_at TIMESTAMPTZ,
                PRIMARY KEY (window_start, symbol)
            )
            """
        )

        for r in rows:
            cur.execute(
                f"""
                INSERT INTO gold_sentiment_price
                ({','.join(cols)})
                VALUES ({','.join(['%s'] * len(cols))})
                ON CONFLICT (window_start, symbol)
                DO UPDATE SET {sets}
                """,
                [r[c] for c in cols],
            )

    con.close()


# =========================================================
# START GOLD STREAMING JOB
# =========================================================

def start_gold(spark, run_id):

    if not settings.SILVER_TICKS_PATH.exists():
        raise FileNotFoundError(
            f"Stock Silver path not found: "
            f"{settings.SILVER_TICKS_PATH}"
        )

    ticks_raw = read_stream(
        spark,
        settings.SILVER_TICKS_PATH,
        SILVER_TICKS_DDL,
        fmt=settings.SILVER_TICKS_FORMAT,
        options={"maxFilesPerTrigger": "50"},
    )

    print("\n[GOLD] INPUT CONFIGURATION")
    print("[GOLD] Stock Silver :", settings.SILVER_TICKS_PATH)
    print("[GOLD] News Silver  :", settings.SILVER_NEWS_PATH)
    print("[GOLD] News enabled :", NEWS_ENABLED)
    print("[GOLD] News max age :", NEWS_MAX_AGE_HOURS, "hours")
    print("[GOLD] Window       :", settings.WINDOW_DURATION)
    print("[GOLD] Slide        :", settings.SLIDE_DURATION)
    print("[GOLD] Watermark    :", settings.WATERMARK)
    print("[GOLD] Trigger      :", settings.GOLD_TRIGGER)
    print("[GOLD] Output mode  : update")
    print("[GOLD] Run tag      :", RUN_TAG)
    print("[GOLD] Gold output  :", settings.GOLD_PATH)
    print("[GOLD] Spark version:", spark.version)
    print("[GOLD] Worker python:", sys.executable)

    if NEWS_ENABLED:
        try:
            _, n = _load_news_snapshot(spark)
            print(f"[GOLD] News snapshot: {n} articles loaded")
        except Exception as error:
            print(f"[GOLD] News snapshot FAILED: {error}")
            print("[GOLD] Continuing with null news columns.")

    price_stream = build_gold_stream(ticks_raw)

    totals = {"rows": 0}

    def process(batch_df, batch_id):

        batch_df.persist()
        news_n = 0

        try:
            if NEWS_ENABLED:
                try:
                    enriched, news_n = _attach_news(
                        spark, batch_df
                    )
                except Exception as error:
                    print(f"[GOLD] News join skipped: {error}")
                    enriched = batch_df
            else:
                enriched = batch_df

            if "avg_sentiment" not in enriched.columns:
                enriched = (
                    enriched
                    .withColumn(
                        "article_count", F.lit(0).cast("int")
                    )
                    .withColumn(
                        "avg_sentiment",
                        F.lit(None).cast("double"),
                    )
                    .withColumn(
                        "min_sentiment",
                        F.lit(None).cast("double"),
                    )
                    .withColumn(
                        "latest_headline",
                        F.lit(None).cast("string"),
                    )
                    .withColumn(
                        "latest_sentiment_label",
                        F.lit(None).cast("string"),
                    )
                )

            final_df = _apply_alerts(enriched)
            final_df.persist()

            stats = final_df.agg(
                F.count("*").alias("n"),
                F.min("window_start").alias("a"),
                F.max("window_end").alias("b"),
                F.sum(
                    F.when(
                        F.col("latest_headline").isNotNull(),
                        F.lit(1),
                    ).otherwise(F.lit(0))
                ).alias("with_news"),
            ).collect()[0]

            n = int(stats["n"])

            _batch_outputs[batch_id] = (
                n,
                stats["a"],
                stats["b"],
                news_n,
            )

            if n == 0:
                print(f"[GOLD] Batch {batch_id}: 0 rows")
                final_df.unpersist()
                return

            print(
                f"[GOLD] Batch {batch_id}: {n} rows, "
                f"{int(stats['with_news'] or 0)} with news "
                f"({stats['a']} .. {stats['b']})"
            )

            try:
                write_batch(
                    final_df,
                    settings.GOLD_PATH,
                    app_id=f"gold-sentiment-price-{RUN_TAG}",
                    batch_id=batch_id,
                )
                print(
                    f"[GOLD] write_batch OK -> "
                    f"{settings.GOLD_PATH}"
                )

            except Exception as error:
                print(f"[GOLD] write_batch FAILED: {error}")

                fallback = (
                    settings.GOLD_PATH.parent
                    / "sentiment_price_parquet"
                )

                (
                    final_df.write
                    .mode("append")
                    .parquet(str(fallback))
                )

                print(f"[GOLD] Parquet fallback -> {fallback}")

            totals["rows"] += n

            if settings.PG_ENABLED:
                try:
                    _postgres_upsert(
                        [r.asDict() for r in final_df.collect()]
                    )
                except Exception as error:
                    print(f"[GOLD] Postgres skipped: {error}")

            audit.job_heartbeat(run_id, JOB, totals["rows"])

            final_df.unpersist()

        except Exception as error:
            print(f"[GOLD] Batch {batch_id} ERROR: {error}")
            raise

        finally:
            batch_df.unpersist()

    spark.streams.addListener(GoldProgressAudit(run_id))

    query = (
        price_stream.writeStream
        .queryName(QUERY_NAME)
        .outputMode("update")
        .foreachBatch(process)
        .option(
            "checkpointLocation",
            str(settings.GOLD_CHECKPOINT_PATH),
        )
        .trigger(processingTime=settings.GOLD_TRIGGER)
        .start()
    )

    print("\n[GOLD] Streaming query started successfully.")
    print("[GOLD] Query ID:", query.id)

    return query